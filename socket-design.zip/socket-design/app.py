
import datetime

from django.shortcuts import render
from flask import Flask, session, request, redirect, url_for, render_template, flash
from flask_socketio import emit, join_room,SocketIO
import os
from matplotlib.style import context
from requests import Response
import query

app = Flask(__name__)   #定义模块名字为APP
app.config.update({     #配置APP模块
    'DEBUG':True,
    'TEMPLATES_AUTO_RELOAD' :True,
    'SECRET_KEY': os.urandom(10)
    
})

socketio = SocketIO()
socketio.init_app(app)   #创建socket实例
user_dict = {}

def getLoginDetails():    #获取用户登录状态
    if 'email' not in session:
        loggedIn = False
        userName = 'please sign in'
    else:
        loggedIn = True
        sql = "SELECT user_name FROM chat.users WHERE email = %s"
        params = [session['email']]
        userName = query.query(sql,params)
        session['user'] = userName[0][0]
    return (loggedIn, userName[0][0])

# 

#判断账户密码是否匹配
def is_valid(email, password):
    sql = 'SELECT email, password FROM chat.users'
    data =query.query_no(sql)
    for row in data:
        if row[0] == email and row[1] == password:
            return True
    return False

#登录
@app.route("/", methods = ['POST', 'GET'])
@app.route("/login", methods = ['POST', 'GET'])
def login():
    
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        user_socket = request.environ.get('wsgi.websocket')
        user_dict[email] = user_socket
        if is_valid(email, str(password)):
            session['email'] = email
            
            return redirect(url_for('index'))
        else:
            # error = 'Invalid UserId / Password'
            
            # info="登录失败！"
            return render_template('login.html', info="登录失败！")
    else:
        
        return render_template('login.html')

@app.route("/logout")
def logout():
    session.pop('email', None)
    return redirect(url_for('login'))


@app.route("/register", methods = ['GET', 'POST'])
def register():
    if request.method == 'POST':
        #Parse form data
        password = request.form['password']
        email = request.form['email']
        name = request.form['name']
        if is_valid(email, password):
            flash('账号已存在，请登录')
            return render_template("login.html")
        else:
            sql = 'INSERT INTO chat.users (email,password,user_name) VALUES (%s,%s,%s)'
            params = [email,password,name]
            msg = query.update(sql,params)
            if msg == 'Changed successfully':
                flash('注册成功')
                return render_template("login.html")
            else:
                flash('注册失败')
                return render_template('register.html')
    else:
        return render_template('register.html')


@app.route("/index", methods = ['POST', 'GET'])
def index():
    if 'email' not in session:
        return redirect(url_for('login'))
    else:
        loggedIn, userName = getLoginDetails()
        sql = "SELECT avatar_url FROM chat.users WHERE email = %s"#获取头像
        params = [session['email']]
        avatar_url = query.query(sql, params)
        sql = "SELECT user_name,users.avatar_url,users.email FROM chat.users" #获取用户名
        users = query.query_no(sql)
        return render_template("index.html",userName = userName,avatar_url=avatar_url[0][0],users = users)

@app.route("/chatroom", methods = ['POST', 'GET'])
def chatroom():
    if 'email' not in session:
        return redirect(url_for('login'))
    else:
        loggedIn, userName = getLoginDetails()
        sql = "SELECT messages.content,messages.create_time,users.user_name,users.avatar_url,messages.user_id FROM chat.messages,chat.users where messages.user_id = users.userid"
        message = query.query_no(sql)
        sql = "SELECT user_name,users.avatar_url FROM chat.users"
        users = query.query_no(sql)
        sql = "SELECT avatar_url FROM chat.users WHERE email = %s"
        params = [session['email']]
        avatar_url = query.query(sql, params)
        return render_template("chatroom.html",userName = userName,message = message,users = users,avatar_url = avatar_url)


#连接聊天室
@socketio.on('connect', namespace='/chatroom')
def connect():
    print('!连接成功')

#加入房间
@socketio.on('joined', namespace='/chatroom')
def joined():
    # 'joined'路由是传入一个room_name,给该websocket连接分配房间,返回一个'status'路由
    room_name = 'chat room'
    user_name = session.get('user')
    # print(user_name)
    print("!!!!!")
    join_room(room_name)
    emit('status', {'server_to_client': user_name + ' enter the room'}, room=room_name)

#接收聊天信息
@socketio.on('text', namespace='/chatroom')
def text(information):
    text = information.get('text')
    print(text)
    user_name = session.get('user') #获取用户名称
    print(user_name)
    sql = "SELECT userid FROM chat.users WHERE email = %s"
    params = [session['email']]
    user_id = query.query(sql, params)  #获取用户ID
    print(user_id)
    create_time = datetime.datetime.now()
    create_time = datetime.datetime.strftime(create_time, '%Y-%m-%d %H:%M:%S')
    sql = 'INSERT INTO chat.messages (content,create_time,user_id) VALUES (%s,%s,%s)'
    params = [text,create_time, user_id]
    msg = query.update(sql, params)  
    print(msg)#将聊天信息插入数据库，更新数据库
    

    
    sql = "SELECT avatar_url FROM chat.users WHERE email = %s"
    params = [session['email']]
    avatar_url = query.query(sql, params)  #获取用户头像
    #返回聊天信息给前端
    
    emit('message', {
        'user_name': user_name,
        'text': text,
        'create_time': create_time,
        'avatar_url':avatar_url,
    })
    chatroom()


#连接主页
@socketio.on('Iconnect', namespace='/index')
def Iconnect():
    print('连接成功!')

#接收更换的头像的路径
@socketio.on('avatar_url' ,namespace='/index')
def avatar_url(information):
    email = session['email']
    print(email)
    avatar_url = information.get('avatar_url')
    print(avatar_url)
    sql = "UPDATE chat.users SET avatar_url = %s WHERE email = %s "
    params = [avatar_url,email]
    msg = query.update(sql, params)
    print(msg)

if __name__ == '__main__':
    #app.run(debug=True, use_reloader=False)
    socketio.run(app, debug=True,host='121.48.199.79', port=5000)
